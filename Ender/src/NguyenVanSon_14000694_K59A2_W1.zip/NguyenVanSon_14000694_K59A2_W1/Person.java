//Name: Nguyen Van Son
//Ender;
//NguyenVanSon_14000694_K59A2_W1;
public class Person {

	public static void main(String[] args) {
		System.out.println("*******************************************");
		System.out.println("* Ho va ten: Nguyen Van Son               *");
		System.out.println("* Ngay sinh: 22/04/1996 Gioi tinh: Nam    *");
		System.out.println("* Que quan: Tu Son, Bac Ninh              *");
		System.out.println("* So thich: Lap trinh                     *");
		System.out.println("*******************************************");

	}

}
